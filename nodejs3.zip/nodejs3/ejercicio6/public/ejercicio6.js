 document.getElementById('registroForm').addEventListener('submit', function(e) {
      e.preventDefault();

// definimos las constantes

      const form = e.target;
      const formData = new FormData(form);

      const nombre = formData.get('nombre');
      const edad = formData.get('edad');
      const email = formData.get('email');
      const genero = formData.get('genero');
      const pais = formData.get('pais');
      const intereses = formData.getAll('intereses').join(', ');

// muestra los resultados elegidos

      const resultadoDiv = document.getElementById('resultado');
      resultadoDiv.innerHTML = `
        <h2>Datos Registrados:</h2>
        <p><strong>Nombre:</strong> ${nombre}</p>
        <p><strong>Edad:</strong> ${edad}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Género:</strong> ${genero}</p>
        <p><strong>País:</strong> ${pais}</p>
        <p><strong>Intereses:</strong> ${intereses || 'Ninguno'}</p>
      `;
    });