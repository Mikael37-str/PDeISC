document.addEventListener('DOMContentLoaded', () => {
  // dirige al resto de paginas
  const links = [
    { id: 'pripag', url: 'evento1.html' },
    { id: 'segpag', url: 'evento2.html' },
    { id: 'terpag', url: 'evento3.html' },
    { id: 'cuapag', url: 'evento4.html' },
    { id: 'quipag', url: 'evento5.html' }
  ];
  links.forEach(link => {
    const el = document.getElementById(link.id);
    if (el) {
      el.addEventListener('click', () => window.location.href = link.url);
    }
  });

  // evento 1, muestra un anuncio cuando se le da play al video
  const video = document.getElementById('miVideo');
  const imagen = document.getElementById('imagen');
  if (video && imagen) {
    video.addEventListener('play', () => {
      imagen.style.display = 'block';
    });
  }

  // evento 2, cuando se apreta la letra K muestra un texto, y cuando se suelta, otro
  const mensaje = document.getElementById('txt');
  if (mensaje) {
    document.addEventListener('keydown', (event) => {
      if (event.key.toLowerCase() === 'k') {
        mensaje.textContent = 'Estas apretando la tecla K';
      }
    });

    document.addEventListener('keyup', (event) => {
      if (event.key.toLowerCase() === 'k') {
        mensaje.textContent = 'Soltaste la tecla K';
      }
    });
  }

  // evento 3, cambia el color del fondo al hacer click en la pagina
  const pagina3 = document.getElementById('p3');
  if (pagina3) {
    const colores = ['green', 'purple', 'orange', 'gray', 'pink'];
    let indice = 0;
    pagina3.addEventListener('click', () => {
      document.body.style.backgroundColor = colores[indice];
      indice = (indice + 1) % colores.length;
    });
  }

  // evento 4, cuando el mouse esta en la zona verde se muestra un mensaje
  const zona = document.getElementById('zona');
  const mensajeZona = document.getElementById('mensaje');
  if (zona && mensajeZona) {
    zona.addEventListener('mousemove', () => {
      mensajeZona.textContent = 'Estás dentro de la zona';
    });
    zona.addEventListener('mouseleave', () => {
      mensajeZona.textContent = '';
    });
  }

  // evento 5, cuando se rueda el mouse cambia el texto en la pagina
  const texto = document.getElementById('texto');
  const pagina5 = document.getElementById('p5');
  if (texto && pagina5) {
    pagina5.addEventListener('wheel', (event) => {
      texto.textContent = event.deltaY > 0
        ? 'Spotify es una empresa sueca de servicios multimedia fundada en el año 2006, cuyo producto es la aplicación homónima empleada para la reproducción de música vía streaming. Su modelo de negocio es el denominado freemium.'
        : 'Instagram (comúnmente abreviado como IG o Insta) es una aplicación y red social propiedad de Meta. Creada por Kevin Systrom y Mike Krieger, fue lanzada el 6 de octubre de 2010. Ganó rápidamente popularidad, llegando a tener más de 100 millones de usuarios activos en abril de 2012 y más de 300 millones en diciembre de 2014,[2]​ Fue diseñada originalmente para iPhone y a su vez está disponible para sus hermanos iPad y iPod con el sistema iOS 3.0.2 o superior. El 3 de abril de 2012, se publicó una versión para Android[3]​ y en 2013 se lanzó la versión beta para Windows Phone y oficial para Windows 10 en 2016.';
    });
  }
});
