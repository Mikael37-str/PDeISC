// define los primeros enlaces
const enlacesData = [
      { texto: 'Google', href: 'https://www.google.com' },
      { texto: 'YouTube', href: 'https://www.youtube.com' },
      { texto: 'Wikipedia', href: 'https://www.wikipedia.org' },
      { texto: 'Classroom', href: 'https://www.classroom.com' },
      { texto: 'Bricklink', href: 'https://www.bricklink.com' }
    ];

// cambia los enlaces
    const nuevosHref = [
      'https://duckduckgo.com',
      'https://vimeo.com',
      'https://es.wiktionary.org',
      'https://https://www.google.com/maps?authuser=0',
      'https://translate.google.com'
    ];

// haciendo click muestra los primeros enlaces
    document.getElementById('crear').addEventListener('click', () => {
      const contenedor = document.getElementById('contenedor');
      contenedor.innerHTML = ''; // elimina los enlaces anteriores
      enlacesData.forEach((item, i) => {
        const enlace = document.createElement('a');
        enlace.href = item.href;
        enlace.textContent = item.texto;
        enlace.setAttribute('data-index', i); 
        contenedor.appendChild(enlace);
      });
      document.getElementById('cambios').innerHTML = ''; 
    });

// haciendo click cambia el contenido de los enlaces
    document.getElementById('modificar').addEventListener('click', () => {
      const enlaces = document.querySelectorAll('#contenedor a');
      enlaces.forEach((enlace, i) => {
        const viejo = enlace.href;
        enlace.href = nuevosHref[i];
        const li = document.createElement('li');
        li.textContent = `Enlace "${enlace.textContent}": href cambiado de "${viejo}" a "${enlace.href}"`;
        document.getElementById('cambios').appendChild(li);
      });
    });