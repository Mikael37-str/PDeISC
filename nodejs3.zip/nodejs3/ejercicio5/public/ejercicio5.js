// funcion para agregar elementos cuando se aprete el boton correspondiente
let contador = 0;

    function agregarElemento(tipo) {
      const contenedor = document.getElementById('contenedor');
      const id = `item-${contador++}`;

// a cada boton le ponemos una funcionalidad

      let contenido = '';
      switch (tipo) {
        case 'p':
          contenido = '<p>Este es un párrafo</p>';
          break;
        case 'img':
          contenido = '<img src="https://www.rebelscum.com/2022/Naboo_1.jpg"';
          break;
        case 'ul':
          contenido = '<ul><li>Manzanas</li><li>Cebollas</li><li>Papas</li></ul>';
          break;
        case 'button':
          contenido = '<button onclick="alert(\'classroom\')">Botón creado</button>';
          break;
        case 'h2':
          contenido = '<h1>Este es un título</h1>';
          break;
      }

      contenedor.innerHTML += `
        <div class="item" id="${id}">
          ${contenido}
          <br>
          <button onclick="eliminarElemento('${id}')">Eliminar</button>
        </div>
      `;
    }
// esta funcion elimina el elemento agregado
    function eliminarElemento(id) {
      const elemento = document.getElementById(id);
      if (elemento) {
        elemento.remove();
      }
    }