const contenido = document.getElementById('contenido');

// se ejecuta cuando se hace click en el boton para agregar texto 

    document.getElementById('agtxt').addEventListener('click', () => {
      if (!document.getElementById('titulo')) {
        const h1 = document.createElement('h1');
        h1.id = 'titulo';
        h1.textContent = 'hola DOM';
        contenido.appendChild(h1);
      }
    });

// se ejecuta cuando se hace click en el boton para cambiar el texto anterior

    document.getElementById('catxt').addEventListener('click', () => {
        const tituloExistente = document.getElementById('titulo');
        
        if (tituloExistente) {
          tituloExistente.remove();
        }
        
        const h1 = document.createElement('h1');
        h1.textContent = 'chau DOM';
        h1.id = 'titulo';
        contenido.appendChild(h1);
    });

// se ejecuta cuando se hace click en el boton para quitar texto 

    document.getElementById('qutxt').addEventListener('click', () => {
      const titulo = document.getElementById('titulo');
      if (titulo) {
        titulo.remove();
      }
    });

// sirve para cambiar el color del texto cuando se hace click en el boton  

    document.getElementById('cctxt').addEventListener('click', () => {
      const titulo = document.getElementById('titulo');
      if (titulo) {
        titulo.style.color = 'green';
      }
    });

// quita el color del texto 

    document.getElementById('qctxt').addEventListener('click', () => {
      const titulo = document.getElementById('titulo');
      if (titulo) {
        titulo.style.color = '';
      }
    });

// se ejecuta cuando se hace click en el boton para agregar una imagen

    document.getElementById('agimg').addEventListener('click', () => {
      if (!document.getElementById('imagen')) {
        const img = document.createElement('img');
        img.id = 'imagen';
        img.src = 'https://s2.abcstatics.com/media/viajar/2015/12/07/chott-el-jerid--510x287.jpg'; 
        contenido.appendChild(img);
      }
    });

// se ejecuta cuando se hace click en el boton para quitar la imagen 

    document.getElementById('quimg').addEventListener('click', () => {
      const imagen = document.getElementById('imagen');
      if (imagen) {
        imagen.remove();
      }
    });

// cambia el tamaño de la imagen

    document.getElementById('ctimg').addEventListener('click', () => {
      const imagen = document.getElementById('imagen');
      if (imagen) {
        imagen.style.width = '150px';
        imagen.style.height = 'auto';
      }
    });