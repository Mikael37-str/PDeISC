import { useState, useEffect } from 'react';
import api from '../services/api';
import ErrorDisplay from '../components/ErrorDisplay';

const ExperiencesPage = () => {
  const [experiences, setExperiences] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchExperiences = async () => {
      try {
        setLoading(true);
        const response = await api.get('/experiences');
        // Ordenar por fecha de inicio (más reciente primero)
        const sortedExperiences = response.data.sort((a, b) => 
          new Date(b.start_date) - new Date(a.start_date)
        );
        setExperiences(sortedExperiences);
        setError(''); // Limpiar cualquier error anterior si la carga es exitosa
      } catch (err) {
        console.error('Error al cargar las experiencias:', err); 
        // Mensaje de error más explícito sobre la conexión
        setError('Error al cargar las experiencias. Por favor, verifica que el servidor de backend esté funcionando y que la URL de la API sea correcta.');
      } finally {
        setLoading(false);
      }
    };
    fetchExperiences();
  }, []);

  const calculateDuration = (startDate, endDate) => {
    const start = new Date(startDate);
    // Usa la fecha actual si la experiencia es 'current'
    const end = endDate === 'current' ? new Date() : new Date(endDate); 
    
    // Calcula la diferencia en meses
    const diffInMonths = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
    
    if (diffInMonths < 1) return "Menos de 1 mes";
    if (diffInMonths < 12) return `${diffInMonths} ${diffInMonths === 1 ? 'mes' : 'meses'}`;

    const years = Math.floor(diffInMonths / 12);
    const months = diffInMonths % 12;
    
    let durationString = `${years} ${years === 1 ? 'año' : 'años'}`;
    if (months > 0) {
      durationString += ` y ${months} ${months === 1 ? 'mes' : 'meses'}`;
    }
    return durationString;
  };

  // ----------------------------------------------------------------------------------
  // ESTADO DE CARGA (LOADING) - Depende de que el CSS @keyframes spin exista
  // ----------------------------------------------------------------------------------
  if (loading) {
    return (
      <main>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center',
          minHeight: '60vh',
          flexDirection: 'column',
          gap: '1rem'
        }}>
          {/* Este div es el spinner que necesita la regla 'spin' en CSS */}
          <div style={{
            width: '50px',
            height: '50px',
            border: '4px solid var(--border-color)',
            borderTop: '4px solid var(--primary-color)',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }}></div>
          <h2 style={{ color: 'var(--text-light)' }}>Cargando experiencias...</h2>
        </div>
      </main>
    );
  }
  
  // ----------------------------------------------------------------------------------
  // ESTADO DE ERROR - Se muestra si falló la API y no hay datos previos
  // ----------------------------------------------------------------------------------
  if (error && experiences.length === 0) {
    return (
      <main>
        <div style={{ padding: '3rem 1rem' }}>
          {/* Muestra el componente de error con el mensaje detallado */}
          <ErrorDisplay message={error} /> 
          <div style={{ textAlign: 'center', padding: '3rem' }}>
            <p style={{ color: 'var(--text-light)' }}>Intenta recargar la página o verifica la conexión del servidor.</p>
          </div>
        </div>
      </main>
    );
  }

  // ----------------------------------------------------------------------------------
  // RENDERIZADO NORMAL
  // ----------------------------------------------------------------------------------
  return (
    <main>
      <section className="section-container fade-in">
        <h2 className="section-title">Experiencia Laboral</h2>
        
        {experiences.length > 0 ? (
          <div className="timeline-container">
            {/* Línea vertical del timeline */}
            <div className="timeline-line"></div> 

            {experiences.map((exp, index) => (
              <div 
                key={exp.id || index} 
                className={`timeline-item ${index % 2 === 0 ? 'left' : 'right'}`}
              >
                <div className="timeline-dot"></div> 
                <div className="timeline-content card">
                  <div style={{ padding: '1.5rem' }}>
                    {/* Encabezado */}
                    <div style={{ marginBottom: '1rem' }}>
                      <h3 style={{ 
                        color: 'var(--primary-color)', 
                        marginBottom: '0.2rem',
                        fontSize: '1.4rem'
                      }}>
                        {exp.title}
                      </h3>
                      <p style={{ 
                        color: 'var(--text-dark)', 
                        fontWeight: '600',
                        fontSize: '1.1rem'
                      }}>
                        {exp.company}
                      </p>
                      <small style={{ 
                        color: 'var(--text-light)',
                        background: 'var(--bg-light)',
                        padding: '0.25rem 0.8rem',
                        borderRadius: '12px',
                        fontSize: '0.85rem',
                        display: 'inline-block',
                        marginTop: '0.5rem'
                      }}>
                        📅 {new Date(exp.start_date).toLocaleDateString('es-ES', { year: 'numeric', month: 'short' })} - {exp.end_date === 'current' ? 'Actualidad' : new Date(exp.end_date).toLocaleDateString('es-ES', { year: 'numeric', month: 'short' })} 
                        <span style={{ marginLeft: '0.5rem', fontWeight: 'bold' }}>
                            ({calculateDuration(exp.start_date, exp.end_date === 'current' ? new Date().toISOString() : exp.end_date)})
                        </span>
                      </small>
                    </div>

                    {/* Descripción */}
                    {exp.description && (
                      <div style={{ marginTop: '1rem' }}>
                        <h4 style={{ 
                          color: 'var(--text-dark)', 
                          marginBottom: '0.5rem', 
                          fontSize: '1.1rem',
                          fontWeight: '600'
                        }}>
                          Responsabilidades:
                        </h4>
                        <p style={{
                          color: 'var(--text-dark)',
                          fontSize: '1rem',
                          textAlign: 'justify',
                          margin: 0
                        }}>
                          {exp.description}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {/* Punto final del timeline */}
            <div style={{
              position: 'absolute',
              left: '24px',
              bottom: '-20px',
              width: '12px',
              height: '12px',
              background: 'var(--text-light)',
              borderRadius: '50%',
              zIndex: 2
            }}></div>
          </div>
        ) : (
          <div style={{
            textAlign: 'center',
            padding: '4rem 2rem',
            color: 'var(--text-light)'
          }}>
            <div style={{
              fontSize: '4rem',
              marginBottom: '1rem',
              opacity: 0.3
            }}>
              💼
            </div>
            <h3 style={{ marginBottom: '0.5rem', color: 'var(--text-dark)' }}>
              No hay experiencias registradas
            </h3>
            <p>Las experiencias profesionales aparecerán aquí cuando se agreguen desde el panel de administración.</p>
          </div>
        )}
      </section>
    </main>
  );
};

export default ExperiencesPage;