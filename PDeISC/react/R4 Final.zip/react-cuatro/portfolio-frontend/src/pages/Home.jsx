import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import ErrorDisplay from '../components/ErrorDisplay';

const Home = () => { // <--- Asegúrate de que esta línea esté presente y correcta.
  const [projects, setProjects] = useState([]);
  const [skills, setSkills] = useState([]);
  const [experiences, setExperiences] = useState([]);
  const [about, setAbout] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [projectsRes, skillsRes, experiencesRes, aboutRes] = await Promise.all([
          api.get('/projects'),
          api.get('/skills'),
          api.get('/experiences'),
          api.get('/about')
        ]);
        setProjects(projectsRes.data.slice(0, 3));
        setSkills(skillsRes.data.slice(0, 2));
        setExperiences(experiencesRes.data.slice(0, 2));
        setAbout(aboutRes.data[0]?.content || 'Bienvenido a mi portfolio profesional donde muestro mis habilidades, proyectos y experiencia en desarrollo web.');
      } catch (err) {
        console.error('Error al cargar datos:', err);
        setError('Error al cargar los datos del portfolio');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Retorno condicional para estado de carga (opcional, pero buena práctica)
  if (loading) {
    return (
      <main>
        <p style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-light)' }}>
          Cargando datos del portfolio...
        </p>
      </main>
    );
  }

  // --- Tu código de renderizado JSX actualizado empieza aquí ---
  return ( 
    <main>
      {error && <ErrorDisplay message={error} />}

      {/* SECCIÓN SOBRE MÍ */}
      <section>
        <h1 className="section-title">Sobre Mí</h1>
        <div className="card">
          <p style={{ lineHeight: '1.8' }}>{about}</p>
          <div style={{ textAlign: 'center', marginTop: '2rem' }}>
            <Link to="/about" className="btn btn-primary">
              Leer más
            </Link>
          </div>
        </div>
      </section>

      {/* SECCIÓN PROYECTOS */}
      <section style={{ marginTop: '4rem' }}>
        <h2 className="section-title">Proyectos Recientes</h2>
        
        {loading ? ( // Nota: Si llegamos a este punto, 'loading' debería ser false debido al 'if' anterior.
          <p style={{ textAlign: 'center', color: 'var(--text-light)' }}>Cargando proyectos...</p>
        ) : (
          <div className="grid-3">
            {projects.map((project) => (
              <div key={project.id} className="card">
                <h3 className="text-primary" style={{ marginBottom: '0.5rem', fontSize: '1.3rem' }}>
                  {project.title}
                </h3>
                <small style={{ color: 'var(--text-light)', display: 'block', marginBottom: '1rem' }}>
                  📅 {new Date(project.date).toLocaleDateString('es-ES')}
                </small>
                <p style={{ lineHeight: '1.6', color: 'var(--text-dark)' }}>
                  {project.description.substring(0, 100)}...
                </p>
                <Link to="/projects" className="btn btn-primary" style={{ marginTop: '1rem', padding: '0.5rem 1rem', fontSize: '0.9rem' }}>
                  Ver Proyecto
                </Link>
              </div>
            ))}
          </div>
        )}

        <div style={{ textAlign: 'center', marginTop: '3rem' }}>
          <Link to="/projects" className="btn btn-primary">
            Ver Todos los Proyectos
          </Link>
        </div>
      </section>

      {/* SECCIÓN EXPERIENCIAS */}
      <section style={{ marginTop: '4rem' }}>
        <h2 className="section-title">Experiencia Destacada</h2>
        
        {loading ? (
          <p style={{ textAlign: 'center', color: 'var(--text-light)' }}>Cargando experiencias...</p>
        ) : (
          <div style={{ maxWidth: '800px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {experiences.map((exp) => (
              <div key={exp.id} className="card">
                <h3 className="text-primary" style={{ marginBottom: '0.5rem', fontSize: '1.3rem' }}>
                  {exp.title}
                </h3>
                <p style={{ fontWeight: '600', marginBottom: '0.5rem', fontSize: '1.1rem' }}>
                  {exp.company}
                </p>
                <small style={{ color: 'var(--text-light)', display: 'block', marginBottom: '1rem' }}>
                  {new Date(exp.start_date).toLocaleDateString('es-ES')} - {new Date(exp.end_date).toLocaleDateString('es-ES')}
                </small>
                <p style={{ lineHeight: '1.6', color: 'var(--text-dark)' }}>
                  {exp.description}
                </p>
              </div>
            ))}
          </div>
        )}

        <div style={{ textAlign: 'center', marginTop: '3rem' }}>
          <Link to="/experiences" className="btn btn-primary">
            Ver Historial Completo
          </Link>
        </div>
      </section>

      {/* SECCIÓN HABILIDADES (SE MANTIENE SIMPLE POR AHORA) */}
      <section style={{ marginTop: '4rem' }}>
        <h2 className="section-title">Habilidades Clave</h2>
        <div className="grid-2" style={{ maxWidth: '600px', margin: '0 auto' }}>
          {skills.map((skill) => (
            <div key={skill.id} className="card" style={{ textAlign: 'center', padding: '1rem' }}>
              <h4 style={{ margin: 0, color: 'var(--text-dark)' }}>{skill.name}</h4>
            </div>
          ))}
        </div>
        <div style={{ textAlign: 'center', marginTop: '3rem' }}>
          <Link to="/skills" className="btn btn-primary">
            Ver Todas las Habilidades
          </Link>
        </div>
      </section>

    </main>
  ); // <--- El 'return' de JSX termina aquí.
}; // <--- La función del componente Home termina aquí.

export default Home;