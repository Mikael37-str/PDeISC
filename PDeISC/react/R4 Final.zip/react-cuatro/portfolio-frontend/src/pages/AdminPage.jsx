import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import ErrorDisplay from '../components/ErrorDisplay';
import ProjectForm from '../components/ProjectForm';
import SkillForm from '../components/SkillForm';
import ExperienceForm from '../components/ExperienceForm';
import AboutForm from '../components/AboutForm';

const AdminPage = () => {
  const { user, loading, logout } = useAuth(); // Aseguramos que 'logout' se extraiga
  const [activeTab, setActiveTab] = useState('projects');
  const [error, setError] = useState(''); // Estado de error local para la página
  const navigate = useNavigate();

  useEffect(() => {
    // Si la carga termina y NO hay usuario, navegamos a /login
    if (!loading && !user) {
      navigate('/login');
    }
    // Si la carga termina y SÍ hay usuario, limpiamos cualquier error anterior
    if (!loading && user) {
        setError('');
    }

    // Nota: El manejo principal de errores (API caída) está en AuthContext.jsx.
    // Si la llamada inicial en AuthContext falla, 'user' será null y 'loading' será false,
    // lo que disparará el 'navigate' a '/login', donde se muestra el error.

  }, [user, loading, navigate]);

  // Manejo del estado de carga (loading)
  if (loading) {
    return (
      <main>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center',
          minHeight: '60vh',
          flexDirection: 'column',
          gap: '1rem'
        }}>
          <div style={{
            width: '50px',
            height: '50px',
            border: '4px solid var(--border-color)',
            borderTop: '4px solid var(--primary-color)',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite' // Necesita @keyframes spin en index.css
          }}></div>
          <h2 style={{ color: 'var(--text-light)' }}>Verificando autenticación...</h2>
        </div>
      </main>
    );
  }

  // Si no hay usuario después de la carga, no renderizamos nada (el useEffect ya redirigió)
  if (!user) {
    return null;
  }

  const tabs = [
    { id: 'projects', label: 'Proyectos'},
    { id: 'skills', label: 'Habilidades'},
    { id: 'experiences', label: 'Experiencias'},
    { id: 'about', label: 'Sobre Mí'}
  ];

  return (
    <main>
      {/* APLICA: admin-header (Estilos eliminados del paso 1 se mantienen) */}
      <div className="admin-header"> 
        <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
          <h1>
            Panel de Administración
          </h1>
          <p>
            Gestiona tu contenido del portfolio
          </p>
        </div>
      </div>

      {/* APLICA: admin-form-container */}
      <div className="admin-form-container"> 
        <div className="card fade-in">
          {/* APLICA: tabs a la navegación */}
          <div className="tabs"> 
            {tabs.map(tab => (
              <button 
                key={tab.id}
                className={activeTab === tab.id ? 'active' : ''} 
                onClick={() => setActiveTab(tab.id)}
              >
                <span>{tab.icon}</span> 
                {tab.label}
              </button>
            ))}
          </div>
          
          <div className="tab-content">
            {/* Si hay un error, se muestra aquí */}
            {error && <ErrorDisplay message={error} />}

            {activeTab === 'projects' && (
              <div className="fade-in">
                {/* Ahora el ProjectForm maneja sus propios errores */}
                <ProjectForm /> 
              </div>
            )}
            {activeTab === 'skills' && (
              <div className="fade-in">
                <SkillForm />
              </div>
            )}
            {activeTab === 'experiences' && (
              <div className="fade-in">
                <ExperienceForm />
              </div>
            )}
            {activeTab === 'about' && (
              <div className="fade-in">
                <AboutForm />
              </div>
            )}
          </div>
          
          <div style={{ marginTop: '2rem', paddingTop: '1rem', borderTop: '1px solid var(--border-color)', textAlign: 'center' }}>
            <button onClick={logout} className="btn btn-danger">
              Cerrar Sesión
            </button>
          </div>
        </div>
      </div>
    </main>
  );
};

export default AdminPage;