import { useState, useEffect } from 'react';
import api from '../services/api';
import ErrorDisplay from '../components/ErrorDisplay';

const SkillsPage = () => {
  const [skills, setSkills] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSkills = async () => {
      try {
        setLoading(true);
        const response = await api.get('/skills');
        setSkills(response.data);
      } catch (err) {
        // Mejorar el manejo del error para asegurar que se muestre el mensaje
        console.error('Error al cargar las habilidades:', err);
        setError('Error al cargar las habilidades');
      } finally {
        setLoading(false);
      }
    };
    fetchSkills();
  }, []);

  // 1. MANEJO DEL ESTADO DE CARGA (LOADING)
  if (loading) {
    // Retorna un spinner o mensaje de carga, basado en patrones comunes de otros archivos.
    return (
      <main>
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '60vh',
          flexDirection: 'column',
          gap: '1rem'
        }}>
          {/* Se asume que la animación 'spin' está definida en index.css */}
          <div style={{
            width: '50px',
            height: '50px',
            border: '4px solid var(--border-color)',
            borderTop: '4px solid var(--primary-color)',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }}></div>
          <h2 style={{ color: 'var(--text-light)' }}>Cargando Habilidades...</h2>
        </div>
      </main>
    );
  }

  // 2. RENDERIZADO PRINCIPAL (CONTENIDO)
  return (
    <main>
      <h1 className="section-title">Mi Stack de Habilidades</h1>
      {error && <ErrorDisplay message={error} />}

      {skills.length > 0 ? (
        <section className="grid-2" style={{ maxWidth: '800px', margin: '0 auto', marginTop: '3rem' }}>
          {skills.map((skill) => (
            <div key={skill.id} className="card" style={{ padding: '1.5rem' }}>
              <h3 style={{ color: 'var(--text-dark)', marginBottom: '0.5rem', fontSize: '1.3rem' }}>
                {skill.name}
              </h3>
              
              {/* Barra de Progreso más estilizada */}
              <div style={{ 
                height: '8px', 
                background: 'var(--bg-light)', 
                borderRadius: '10px', 
                marginBottom: '0.5rem',
                overflow: 'hidden' 
              }}>
                <div style={{
                  width: `${skill.level}%`,
                  height: '100%',
                  background: 'var(--secondary-color)', 
                  transition: 'width 0.5s ease'
                }}></div>
              </div>
              
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: 'var(--text-light)', fontSize: '0.85rem' }}>
                  Nivel: {skill.level}%
                </span>
                <span style={{ 
                  padding: '0.3rem 0.6rem',
                  borderRadius: '6px',
                  fontSize: '0.8rem',
                  fontWeight: '600',
                  background: skill.level >= 80 ? 'var(--accent-color)' : 'var(--border-color)',
                  color: skill.level >= 80 ? 'var(--text-dark)' : 'var(--text-light)'
                }}>
                  {skill.level >= 80 ? 'Experto' : 'Avanzado'}
                </span>
              </div>
            </div>
          ))}
        </section>
      ) : (
        /* Mensaje de "No hay habilidades" */
        <div style={{ textAlign: 'center', padding: '4rem 2rem', color: 'var(--text-light)' }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem', opacity: 0.3 }}>
            ⚡
          </div>
          <h3 style={{ marginBottom: '0.5rem', color: 'var(--text-dark)' }}>
            No hay habilidades registradas
          </h3>
          <p>Las habilidades aparecerán aquí cuando se agreguen desde el panel de administración.</p>
        </div>
      )}
    </main>
  );
};

export default SkillsPage;