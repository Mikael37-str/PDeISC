import { useState, useEffect } from 'react';
import api from '../services/api';
import ErrorDisplay from '../components/ErrorDisplay';

const ProjectsPage = () => {
  const [projects, setProjects] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setLoading(true);
        const response = await api.get('/projects');
        setProjects(response.data);
      } catch (err) {
        setError('Error al cargar los proyectos');
      } finally {
        setLoading(false);
      }
    };
    fetchProjects();
  }, []);

  if (loading) {
    return (
      <main>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center',
          minHeight: '60vh',
          flexDirection: 'column',
          gap: '1rem'
        }}>
          <div style={{
            width: '50px',
            height: '50px',
            border: '4px solid var(--border-color)',
            borderTop: '4px solid var(--primary-color)',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }}></div>
          <h2 style={{ color: 'var(--text-light)' }}>Cargando proyectos...</h2>
        </div>
      </main>
    );
  }
  
 return (
  <main>
    <h1 className="section-title">Todos mis Proyectos</h1>
    {error && <ErrorDisplay message={error} />}

    {loading ? (
      // El spinner de carga se mantiene igual por ahora
      // (Opcional: puedes envolverlo en una clase 'loading-container' en index.css)
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh', flexDirection: 'column', gap: '1rem' }}>
        <div style={{ width: '50px', height: '50px', border: '4px solid var(--border-color)', borderTop: '4px solid var(--primary-color)', borderRadius: '50%', animation: 'spin 1s linear infinite' }}></div>
        <h2 style={{ color: 'var(--text-light)' }}>Cargando proyectos...</h2>
      </div>
    ) : projects.length > 0 ? (
      <section className="grid-3" style={{ marginTop: '3rem' }}>
        {projects.map((project) => (
          // Estructura de Tarjeta Limpia
          <div key={project.id} className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <h2 className="text-primary" style={{ marginBottom: '0.5rem', fontSize: '1.5rem' }}>
                {project.title}
              </h2>
              <small style={{ color: 'var(--text-light)', display: 'block', marginBottom: '1rem' }}>
                📅 {new Date(project.date).toLocaleDateString('es-ES')}
              </small>
              <p style={{ lineHeight: '1.6', color: 'var(--text-dark)', marginBottom: '1.5rem' }}>
                {project.description}
              </p>
            </div>
            
            {project.image_url && (
              <div style={{ 
                borderRadius: '8px', 
                overflow: 'hidden', 
                marginTop: '1rem',
                border: '1px solid var(--border-color)'
              }}>
                <img 
                  src={project.image_url} 
                  alt={`Imagen de ${project.title}`} 
                  style={{ width: '100%', height: 'auto', display: 'block' }} 
                />
              </div>
            )}

            <div style={{ marginTop: '1.5rem' }}>
              {/* Opcional: Agregar botones de Demo/Repo si existen en el modelo de datos */}
            </div>
          </div>
        ))}
      </section>
    ) : (
      // ... (El mensaje de "No hay proyectos" se mantiene igual)
      <div style={{ textAlign: 'center', padding: '4rem 2rem', color: 'var(--text-light)' }}>
        <div style={{ fontSize: '4rem', marginBottom: '1rem', opacity: 0.3 }}>
          🚀
        </div>
        <h3 style={{ marginBottom: '0.5rem', color: 'var(--text-dark)' }}>
          No hay proyectos disponibles
        </h3>
        <p>Los proyectos aparecerán aquí cuando se agreguen desde el panel de administración.</p>
      </div>
    )}
  </main>
);
}; 
export default ProjectsPage;