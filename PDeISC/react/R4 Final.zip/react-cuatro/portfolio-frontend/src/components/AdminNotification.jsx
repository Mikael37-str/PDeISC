import React from 'react';

// Componente simple de notificación flotante (solo para Éxito/Error).
const AdminNotification = ({ message, type = 'info', onCancel }) => {
  if (!message) return null;

  let backgroundColor, color, title;
  
  switch (type) {
    case 'success':
      backgroundColor = '#d1fae5'; 
      color = '#065f46'; 
      title = 'Éxito';
      break;
    case 'error':
      backgroundColor = '#fee2e2'; 
      color = '#991b1b'; 
      title = 'Error';
      break;
    default:
      backgroundColor = '#e0f2f1'; 
      color = '#0e7490'; 
      title = 'Información';
      break;
  }

  // Ocultar automáticamente después de 4 segundos (para éxito/info)
  if (type !== 'error' && onCancel) {
      setTimeout(onCancel, 4000);
  }

  return (
    <div style={{
      position: 'fixed',
      top: '0',
      left: '0',
      width: '100%',
      zIndex: '1000',
      padding: '1rem',
      display: 'flex',
      justifyContent: 'center',
    }}>
      <div 
        className="fade-in"
        style={{
          backgroundColor,
          color,
          padding: '1rem 1.5rem',
          borderRadius: '8px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          maxWidth: '500px',
          width: '90%',
          textAlign: 'left',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.75rem',
          border: `1px solid ${color}`
        }}
      >
        <p style={{ fontWeight: '700', margin: 0 }}>{title}</p>
        <p style={{ margin: 0, fontSize: '0.9rem' }}>{message}</p>
        
        {/* Mostrar botón de cerrar solo si es error, para que el usuario tenga que confirmar la lectura */}
        {type === 'error' && (
             <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
                <button 
                  onClick={onCancel}
                  className="btn btn-secondary"
                  style={{ padding: '0.5rem 1rem', fontSize: '0.9rem', background: 'white', color: color, border: `1px solid ${color}` }}
                >
                  Cerrar
                </button>
            </div>
        )}

      </div>
    </div>
  );
};

export default AdminNotification;