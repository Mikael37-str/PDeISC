import { useState, useEffect } from 'react';
import api from '../services/api';
import ErrorDisplay from './ErrorDisplay';
import AdminNotification from './AdminNotification'; 

const AboutForm = () => {
  const [aboutData, setAboutData] = useState(null);
  const [content, setContent] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null); 

  useEffect(() => {
    const fetchAbout = async () => {
      try {
        const response = await api.get('/about');
        const data = response.data[0];
        setAboutData(data);
        setContent(data?.content || '');
      } catch (err) {
        setError('No se pudo cargar la información de "Sobre mí"');
      }
    };
    fetchAbout();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim()) {
      setError('El contenido no puede estar vacío');
      return;
    }

    setLoading(true);
    setError('');

    try {
      if (aboutData && aboutData.id) {
        await api.put(`/about/${aboutData.id}`, { content });
      } else {
        await api.post('/about', { content });
      }
      
      const response = await api.get('/about');
      const data = response.data[0];
      setAboutData(data);
      setContent(data?.content || '');

      setNotification({ message: 'Información de "Sobre Mí" guardada con éxito.', type: 'success' });
      setTimeout(() => setNotification(null), 3000); 

    } catch (err) {
      setError('Error al guardar la información');
      setNotification({ message: 'Ocurrió un error al intentar guardar la información.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <AdminNotification 
          message={notification?.message} 
          type={notification?.type} 
          onCancel={() => setNotification(null)} 
      />
      
      <h2>Editar Información "Sobre Mí"</h2>

      {error && <ErrorDisplay message={error} />}

      <form onSubmit={handleSubmit}>
        <div className="input-group form-grid-full"> 
          <label htmlFor="about-content">Contenido de "Sobre Mí"</label>
          <textarea
            id="about-content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Cuéntanos sobre ti, tu experiencia, intereses y objetivos profesionales..."
            rows="8"
            required
            disabled={loading}
          />
        </div>

        <button 
          type="submit" 
          className="btn btn-primary"
          disabled={loading || !content.trim()}
          style={{ marginTop: '1.5rem', alignSelf: 'flex-start' }}
        >
          <span>{loading ? 'Guardando...' : 'Guardar Información'}</span>
        </button>
      </form>
      
      
      {content && (
        <div style={{ marginTop: '2rem' }}>
          <h3>Vista Previa:</h3>
          <div className="preview-box">
            {content}
          </div>
        </div>
      )}
    </div>
  );
};

export default AboutForm;