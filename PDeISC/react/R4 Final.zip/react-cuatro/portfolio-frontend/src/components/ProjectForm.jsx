import { useState, useEffect } from 'react';
import api from '../services/api';
import ErrorDisplay from './ErrorDisplay';
import AdminNotification from './AdminNotification'; 

const ProjectForm = () => {
  const [projects, setProjects] = useState([]);
  const [newProject, setNewProject] = useState({
    title: '',
    description: '',
    image_url: '',
    date: ''
  });
  const [editingProject, setEditingProject] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null); 
  // Estado para manejar la confirmación de eliminación por ID
  const [confirmingDeleteId, setConfirmingDeleteId] = useState(null); 

  const getCurrentDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await api.get('/projects');
        setProjects(response.data);
      } catch (err) {
        setError('No se pudieron cargar los proyectos');
        setNotification({ message: 'Error al cargar los proyectos del servidor.', type: 'error' });
      }
    };
    fetchProjects();
  }, []);

  const handleChange = (e) => {
    setNewProject({ ...newProject, [e.target.name]: e.target.value });
  };

  const resetForm = () => {
    setNewProject({
      title: '',
      description: '',
      image_url: '',
      date: getCurrentDate()
    });
    setEditingProject(null);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!newProject.title.trim()) {
      setError('El título del proyecto es obligatorio');
      return;
    }
    
    if (!newProject.description.trim()) {
      setError('La descripción del proyecto es obligatoria');
      return;
    }

    setLoading(true);
    setError('');
    setConfirmingDeleteId(null); 

    try {
      const isEditing = !!editingProject;
      if (isEditing) {
        await api.put(`/projects/${editingProject.id}`, newProject);
        setEditingProject(null);
      } else {
        await api.post('/projects', newProject);
      }
      
      const response = await api.get('/projects');
      setProjects(response.data);
      resetForm();
      
      const message = isEditing ? 'Proyecto actualizado con éxito.' : 'Nuevo proyecto añadido con éxito.';
      setNotification({ message, type: 'success' });
      setTimeout(() => setNotification(null), 3000);

    } catch (err) {
      setError(`Error al ${editingProject ? 'actualizar' : 'crear'} el proyecto`);
      setNotification({ message: 'Ocurrió un error al guardar el proyecto.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (project) => {
    setEditingProject(project);
    setNewProject({
      title: project.title,
      description: project.description,
      image_url: project.image_url,
      date: project.date.split('T')[0] 
    });
    setError('');
    setConfirmingDeleteId(null); 
  };

  // 1. Inicia la confirmación (al hacer clic en "Eliminar")
  const startDeleteConfirmation = (id) => {
    setConfirmingDeleteId(id);
  };

  // 2. Ejecuta la eliminación (al hacer clic en "Confirmar")
  const handleDelete = async (id, title) => {
    setConfirmingDeleteId(null); 
    setLoading(true);
    setError('');

    try {
      await api.delete(`/projects/${id}`);
      const response = await api.get('/projects');
      setProjects(response.data);
      
      setNotification({ message: `Proyecto "${title}" eliminado con éxito.`, type: 'success' });
      setTimeout(() => setNotification(null), 3000);
    } catch (err) {
      setError('Error al eliminar el proyecto');
      setNotification({ message: 'Ocurrió un error al eliminar el proyecto.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  // 3. Cancela la eliminación (al hacer clic en "Cancelar")
  const cancelDelete = () => {
    setConfirmingDeleteId(null);
  };

  return (
    <div>
      <AdminNotification 
          message={notification?.message} 
          type={notification?.type} 
          onCancel={() => setNotification(null)}
      />

      <h2>
        {editingProject ? 'Editar Proyecto' : 'Añadir Nuevo Proyecto'}
      </h2>
      
      {error && <ErrorDisplay message={error} />}
      
      <form onSubmit={handleSubmit}>
        <div className="form-grid"> 
          
          <div className="input-group"> 
            <label htmlFor="title">Título</label>
            <input
              id="title"
              type="text"
              name="title"
              value={newProject.title}
              onChange={handleChange}
              required
              disabled={loading}
            />
          </div>
          
          <div className="input-group"> 
            <label htmlFor="date">Fecha</label>
            <input
              id="date"
              type="date"
              name="date"
              value={newProject.date}
              onChange={handleChange}
              max={getCurrentDate()}
              required
              disabled={loading}
            />
          </div>
          
          <div className="input-group form-grid-full"> 
            <label htmlFor="image_url">URL de Imagen (Opcional)</label>
            <input
              id="image_url"
              type="url"
              name="image_url"
              value={newProject.image_url}
              onChange={handleChange}
              disabled={loading}
            />
          </div>
          
          <div className="input-group form-grid-full"> 
            <label htmlFor="description">Descripción</label>
            <textarea
              id="description"
              name="description"
              value={newProject.description}
              onChange={handleChange}
              rows="4"
              required
              disabled={loading}
            />
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
          <button 
            type="submit" 
            className="btn btn-primary"
            disabled={loading}
          >
            {loading ? 'Guardando...' : editingProject ? 'Actualizar Proyecto' : 'Añadir Proyecto'}
          </button>
          
          {editingProject && (
            <button 
              type="button" 
              onClick={resetForm} 
              className="btn btn-secondary"
            >
              Cancelar Edición
            </button>
          )}
        </div>
      </form>

      <h3 style={{ marginTop: '3rem' }}>Proyectos Registrados</h3>
      
      <div className="grid-admin">
        {projects.length > 0 ? projects.map(project => (
          <div key={project.id} className="admin-item-card fade-in">
            <div style={{ flexGrow: 1 }}>
              <h3>{project.title}</h3>
              
              {project.image_url && (
                <div style={{ marginBottom: '1rem' }}>
                  <img 
                    src={project.image_url} 
                    alt={project.title} 
                    style={{ 
                      maxWidth: '100%', 
                      height: 'auto', 
                      borderRadius: '8px', 
                      objectFit: 'cover',
                      border: '1px solid var(--border-color)'
                    }}
                  />
                </div>
              )}
              
              {project.date && (
                <div style={{ marginBottom: '1rem' }}>
                  <small style={{ 
                    color: 'var(--text-light)',
                    background: 'var(--bg-light)',
                    padding: '0.25rem 0.8rem',
                    borderRadius: '12px',
                    fontSize: '0.85rem'
                  }}>
                    📅 {new Date(project.date).toLocaleDateString('es-ES')}
                  </small>
                </div>
              )}
              
              <p style={{ 
                lineHeight: '1.5',
                color: 'var(--text-dark)',
                marginBottom: '1rem'
              }}>
                {project.description}
              </p>
            </div>

            {/* Lógica de confirmación en la interfaz */}
            <div className="admin-actions">
              {confirmingDeleteId === project.id ? (
                <>
                  <button 
                    onClick={() => handleDelete(project.id, project.title)}
                    className="btn-danger"
                    style={{ background: '#dc2626' }}
                    disabled={loading}
                  >
                    Confirmar Eliminación
                  </button>
                  <button 
                    onClick={cancelDelete}
                    className="btn-secondary"
                    disabled={loading}
                  >
                    Cancelar
                  </button>
                </>
              ) : (
                <>
                  <button 
                    onClick={() => handleEdit(project)}
                    className="btn-secondary"
                    disabled={loading}
                  >
                    Editar
                  </button>
                  <button 
                    onClick={() => startDeleteConfirmation(project.id)}
                    className="btn-danger"
                    disabled={loading}
                  >
                    Eliminar
                  </button>
                </>
              )}
            </div>
          </div>
        )) : (
          <div style={{ 
            textAlign: 'center', 
            padding: '3rem', 
            color: 'var(--text-light)',
            gridColumn: '1 / -1'
          }}>
            <p>No hay proyectos registrados</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectForm;