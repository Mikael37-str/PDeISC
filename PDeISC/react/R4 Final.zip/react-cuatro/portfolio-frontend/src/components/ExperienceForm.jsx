import { useState, useEffect } from 'react';
import api from '../services/api';
import ErrorDisplay from './ErrorDisplay';
import AdminNotification from './AdminNotification'; 

const ExperienceForm = () => {
  const [experiences, setExperiences] = useState([]);
  const [newExperience, setNewExperience] = useState({
    title: '',
    company: '',
    start_date: '',
    end_date: '',
    description: ''
  });
  const [editingExperience, setEditingExperience] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null);
  // Estado para manejar la confirmación de eliminación por ID
  const [confirmingDeleteId, setConfirmingDeleteId] = useState(null); 

  const getCurrentDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  useEffect(() => {
    const fetchExperiences = async () => {
      try {
        const response = await api.get('/experiences');
        setExperiences(response.data);
      } catch (err) {
        setError('No se pudieron cargar las experiencias');
      }
    };
    fetchExperiences();
  }, []);

  const handleChange = (e) => {
    setNewExperience({ ...newExperience, [e.target.name]: e.target.value });
  };

  const resetForm = () => {
    setNewExperience({
      title: '',
      company: '',
      start_date: '',
      end_date: '',
      description: ''
    });
    setEditingExperience(null);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!newExperience.title.trim()) {
      setError('El título del puesto es obligatorio');
      return;
    }
    
    if (!newExperience.company.trim()) {
      setError('El nombre de la empresa es obligatorio');
      return;
    }

    if (!newExperience.start_date) {
      setError('La fecha de inicio es obligatoria');
      return;
    }
    
    if (new Date(newExperience.start_date) > new Date(newExperience.end_date) && newExperience.end_date) {
        setError('La fecha de fin no puede ser anterior a la de inicio.');
        return;
    }

    setLoading(true);
    setError('');
    setConfirmingDeleteId(null);

    try {
      const isEditing = !!editingExperience;
      if (isEditing) {
        await api.put(`/experiences/${editingExperience.id}`, newExperience);
        setEditingExperience(null);
      } else {
        await api.post('/experiences', newExperience);
      }
      
      const response = await api.get('/experiences');
      setExperiences(response.data);
      resetForm();

      const message = isEditing ? 'Experiencia actualizada con éxito.' : 'Nueva experiencia añadida con éxito.';
      setNotification({ message, type: 'success' });
      setTimeout(() => setNotification(null), 3000);

    } catch (err) {
      setError(`Error al ${editingExperience ? 'actualizar' : 'crear'} la experiencia`);
      setNotification({ message: 'Ocurrió un error al guardar la experiencia.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (exp) => {
    setEditingExperience(exp);
    setNewExperience({
      title: exp.title,
      company: exp.company,
      start_date: exp.start_date.split('T')[0],
      end_date: exp.end_date ? exp.end_date.split('T')[0] : '',
      description: exp.description || '' 
    });
    setError('');
    setConfirmingDeleteId(null);
  };

  // 1. Inicia la confirmación
  const startDeleteConfirmation = (id) => {
    setConfirmingDeleteId(id);
  };

  // 2. Ejecuta la eliminación
  const handleDelete = async (id) => {
    setConfirmingDeleteId(null);
    setLoading(true);
    setError('');

    try {
      await api.delete(`/experiences/${id}`);
      const response = await api.get('/experiences');
      setExperiences(response.data);
      
      setNotification({ message: `Experiencia eliminada con éxito.`, type: 'success' });
      setTimeout(() => setNotification(null), 3000);
    } catch (err) {
      setError('Error al eliminar la experiencia');
      setNotification({ message: 'Ocurrió un error al eliminar la experiencia.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  // 3. Cancela la eliminación
  const cancelDelete = () => {
    setConfirmingDeleteId(null);
  };

  return (
    <div>
      <AdminNotification 
          message={notification?.message} 
          type={notification?.type} 
          onCancel={() => setNotification(null)}
      />
      
      <h2>
        {editingExperience ? 'Editar Experiencia' : 'Añadir Nueva Experiencia'}
      </h2>
      
      {error && <ErrorDisplay message={error} />}
      
      <form onSubmit={handleSubmit}>
        <div className="form-grid">
          
          <div className="input-group">
            <label htmlFor="title">Título del Puesto</label>
            <input
              id="title"
              type="text"
              name="title"
              value={newExperience.title}
              onChange={handleChange}
              required
              disabled={loading}
            />
          </div>
          
          <div className="input-group">
            <label htmlFor="company">Empresa / Institución</label>
            <input
              id="company"
              type="text"
              name="company"
              value={newExperience.company}
              onChange={handleChange}
              required
              disabled={loading}
            />
          </div>
          
          <div className="input-group">
            <label htmlFor="start_date">Fecha de Inicio</label>
            <input
              id="start_date"
              type="date"
              name="start_date"
              value={newExperience.start_date}
              onChange={handleChange}
              max={getCurrentDate()}
              required
              disabled={loading}
            />
          </div>
          
          <div className="input-group">
            <label htmlFor="end_date">Fecha de Fin (Dejar vacío si es actual)</label>
            <input
              id="end_date"
              type="date"
              name="end_date"
              value={newExperience.end_date}
              onChange={handleChange}
              max={getCurrentDate()}
              disabled={loading}
            />
          </div>
          
          <div className="input-group form-grid-full">
            <label htmlFor="description">Descripción (Logros/Tareas)</label>
            <textarea
              id="description"
              name="description"
              value={newExperience.description}
              onChange={handleChange}
              rows="4"
              disabled={loading}
            />
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
          <button 
            type="submit" 
            className="btn btn-primary"
            disabled={loading}
          >
            {loading ? 'Guardando...' : editingExperience ? 'Actualizar Experiencia' : 'Añadir Experiencia'}
          </button>
          
          {editingExperience && (
            <button 
              type="button" 
              onClick={resetForm} 
              className="btn btn-secondary"
            >
              Cancelar Edición
            </button>
          )}
        </div>
      </form>

      <h3 style={{ marginTop: '3rem' }}>Experiencias Registradas</h3>
      
      <div className="grid-admin">
        {experiences.length > 0 ? experiences.map(exp => (
          <div key={exp.id} className="admin-item-card fade-in">
            <div style={{ flexGrow: 1 }}>
              <h3>{exp.title}</h3>
              <p style={{ color: 'var(--primary-dark)', fontWeight: '600' }}>
                {exp.company}
              </p>
              
              <small style={{ color: 'var(--text-light)', display: 'block', marginBottom: '1rem' }}>
                {new Date(exp.start_date).toLocaleDateString('es-ES')} - {exp.end_date ? new Date(exp.end_date).toLocaleDateString('es-ES') : 'Actual'}
              </small>
              
              {exp.description && (
                <p style={{ lineHeight: '1.5', color: 'var(--text-dark)' }}>
                  {exp.description}
                </p>
              )}
            </div>

            {/* Lógica de confirmación en la interfaz */}
            <div className="admin-actions">
              {confirmingDeleteId === exp.id ? (
                  <>
                      <button 
                          onClick={() => handleDelete(exp.id)}
                          className="btn-danger"
                          style={{ background: '#dc2626' }}
                          disabled={loading}
                      >
                          Confirmar Eliminación
                      </button>
                      <button 
                          onClick={cancelDelete}
                          className="btn-secondary"
                          disabled={loading}
                      >
                          Cancelar
                      </button>
                  </>
              ) : (
                  <>
                      <button 
                          onClick={() => handleEdit(exp)}
                          className="btn-secondary"
                          disabled={loading}
                      >
                          Editar
                      </button>
                      <button 
                          onClick={() => startDeleteConfirmation(exp.id)}
                          className="btn-danger"
                          disabled={loading}
                      >
                          Eliminar
                      </button>
                  </>
              )}
            </div>
          </div>
        )) : (
          <div style={{ 
            textAlign: 'center', 
            padding: '3rem', 
            color: 'var(--text-light)',
            gridColumn: '1 / -1'
          }}>
            <p>No hay experiencias registradas</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExperienceForm;