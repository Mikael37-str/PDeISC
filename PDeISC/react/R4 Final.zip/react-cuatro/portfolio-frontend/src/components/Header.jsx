import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Header = () => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const handleLogout = () => {
    logout();
  };

  const navLinks = [
    { to: '/', label: 'Inicio' },
    { to: '/projects', label: 'Proyectos' },
    { to: '/skills', label: 'Habilidades' },
    { to: '/experiences', label: 'Experiencia' },
  ];

  const adminLink = { to: '/admin', label: 'Admin' };
  const loginLink = { to: '/login', label: 'Login' };

  const getLinkStyle = (to) => {
    const active = location.pathname === to;
    
    return {
      padding: '0.5rem 1rem', // Reducido para hacer el nav más chico
      color: active ? 'var(--secondary-color)' : 'white', // Color de texto normal y activo
      textDecoration: 'none',
      fontWeight: active ? '600' : '400',
      transition: 'color 0.3s',
      borderRadius: '4px',
      // Estilo de hover simplificado para escritorio
      '&:hover': {
        color: 'var(--secondary-color)',
        opacity: active ? '1' : '0.8'
      }
    };
  };

  return (
    <header style={{ 
      background: 'var(--text-dark)', 
      padding: '0.75rem 0' // Reducido el padding vertical
    }}>
      <div className="header-content" style={{ 
        maxWidth: '1200px', 
        margin: '0 auto', 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        padding: '0 1rem' 
      }}>
        {/* Logo */}
        <Link to="/" className="logo" style={{ 
          color: 'white', 
          fontSize: '1.5rem', 
          fontWeight: 'bold', 
          textDecoration: 'none' 
        }}>
          Peralta Micel
        </Link>
        
        {/* Navegación (siempre visible y horizontal) */}
        <nav style={{ display: 'flex', gap: '1rem' }}>
          {navLinks.map((link) => (
            <Link 
              key={link.to} 
              to={link.to} 
              style={getLinkStyle(link.to)}
              // Esto simula el hover ya que no podemos usar :hover en style
              onMouseEnter={(e) => e.target.style.color = 'var(--secondary-color)'}
              onMouseLeave={(e) => e.target.style.color = location.pathname === link.to ? 'var(--secondary-color)' : 'white'}
            >
              {link.label}
            </Link>
          ))}

          {/* Enlaces de Admin/Login */}
          {user ? (
            <>
              <Link 
                to={adminLink.to} 
                style={getLinkStyle(adminLink.to)}
                onMouseEnter={(e) => e.target.style.color = 'var(--secondary-color)'}
                onMouseLeave={(e) => e.target.style.color = location.pathname === adminLink.to ? 'var(--secondary-color)' : 'white'}
              >
                {adminLink.label}
              </Link>
              <button 
                onClick={handleLogout} 
                style={{ 
                  ...getLinkStyle(''), // Usa un estilo base
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  padding: '0.5rem 0', // Ajusta padding en el botón
                  color: 'white' // Color inicial del botón
                }}
                onMouseEnter={(e) => e.target.style.color = 'var(--secondary-color)'}
                onMouseLeave={(e) => e.target.style.color = 'white'}
              >
                Logout
              </button>
            </>
          ) : (
            <Link 
              to={loginLink.to} 
              style={getLinkStyle(loginLink.to)}
              onMouseEnter={(e) => e.target.style.color = 'var(--secondary-color)'}
              onMouseLeave={(e) => e.target.style.color = location.pathname === loginLink.to ? 'var(--secondary-color)' : 'white'}
            >
              {loginLink.label}
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;