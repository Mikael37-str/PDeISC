import { useState, useEffect } from 'react';
import api from '../services/api';
import ErrorDisplay from './ErrorDisplay';
import AdminNotification from './AdminNotification'; 

const SkillForm = () => {
  const [skills, setSkills] = useState([]);
  const [newSkill, setNewSkill] = useState({ name: '', level: '' });
  const [editingSkill, setEditingSkill] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null); 
  // Estado para manejar la confirmación de eliminación por ID
  const [confirmingDeleteId, setConfirmingDeleteId] = useState(null); 

  useEffect(() => {
    const fetchSkills = async () => {
      try {
        const response = await api.get('/skills');
        setSkills(response.data);
      } catch (err) {
        setError('No se pudieron cargar las habilidades');
      }
    };
    fetchSkills();
  }, []);

  const handleChange = (e) => {
    setNewSkill({ ...newSkill, [e.target.name]: e.target.value });
  };

  const resetForm = () => {
    setNewSkill({ name: '', level: '' });
    setEditingSkill(null);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!newSkill.name.trim()) {
      setError('El nombre de la habilidad es obligatorio');
      return;
    }
    
    if (!newSkill.level || newSkill.level < 1 || newSkill.level > 100) {
      setError('El porcentaje debe estar entre 1 y 100');
      return;
    }

    setLoading(true);
    setError('');
    setConfirmingDeleteId(null);

    try {
      const isEditing = !!editingSkill;
      if (isEditing) {
        await api.put(`/skills/${editingSkill.id}`, newSkill);
        setEditingSkill(null);
      } else {
        await api.post('/skills', newSkill);
      }
      
      const response = await api.get('/skills');
      setSkills(response.data);
      resetForm();
      
      const message = isEditing ? 'Habilidad actualizada con éxito.' : 'Nueva habilidad añadida con éxito.';
      setNotification({ message, type: 'success' });
      setTimeout(() => setNotification(null), 3000);
    } catch (err) {
      setError(`Error al ${editingSkill ? 'actualizar' : 'crear'} la habilidad`);
      setNotification({ message: 'Ocurrió un error al guardar la habilidad.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };
  
  const handleEdit = (skill) => {
    setEditingSkill(skill);
    setNewSkill({ name: skill.name, level: skill.level });
    setError('');
    setConfirmingDeleteId(null);
  };

  // 1. Inicia la confirmación
  const startDeleteConfirmation = (id) => {
    setConfirmingDeleteId(id);
  };

  // 2. Ejecuta la eliminación
  const handleDelete = async (id, name) => {
    setConfirmingDeleteId(null);
    setLoading(true);
    setError('');

    try {
      await api.delete(`/skills/${id}`);
      const response = await api.get('/skills');
      setSkills(response.data);
      
      setNotification({ message: `Habilidad "${name}" eliminada con éxito.`, type: 'success' });
      setTimeout(() => setNotification(null), 3000);
    } catch (err) {
      setError('Error al eliminar la habilidad');
      setNotification({ message: 'Ocurrió un error al eliminar la habilidad.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  // 3. Cancela la eliminación
  const cancelDelete = () => {
    setConfirmingDeleteId(null);
  };

  return (
    <div>
      <AdminNotification 
          message={notification?.message} 
          type={notification?.type} 
          onCancel={() => setNotification(null)}
      />
      
      <h2>
        {editingSkill ? 'Editar Habilidad' : 'Añadir Nueva Habilidad'}
      </h2>
      
      {error && <ErrorDisplay message={error} />}
      
      <form onSubmit={handleSubmit}>
        <div className="form-grid">
          
          <div className="input-group">
            <label htmlFor="name">Nombre de la Habilidad</label>
            <input
              id="name"
              type="text"
              name="name"
              value={newSkill.name}
              onChange={handleChange}
              required
              disabled={loading}
            />
          </div>
          
          <div className="input-group">
            <label htmlFor="level">Porcentaje de Dominio (1-100)</label>
            <input
              id="level"
              type="number"
              name="level"
              value={newSkill.level}
              onChange={handleChange}
              min="1"
              max="100"
              required
              disabled={loading}
            />
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
          <button 
            type="submit" 
            className="btn btn-primary"
            disabled={loading}
          >
            {loading ? 'Guardando...' : editingSkill ? 'Actualizar Habilidad' : 'Añadir Habilidad'}
          </button>
          
          {editingSkill && (
            <button 
              type="button" 
              onClick={resetForm} 
              className="btn btn-secondary"
            >
              Cancelar Edición
            </button>
          )}
        </div>
      </form>

      <h3 style={{ marginTop: '3rem' }}>Habilidades Registradas</h3>
      
      <div className="grid-admin">
        {skills.length > 0 ? skills.map(skill => (
          <div key={skill.id} className="admin-item-card fade-in">
            <div style={{ flexGrow: 1, marginBottom: '1rem' }}>
              <h3>{skill.name}</h3>
              
              <div style={{ marginBottom: '0.5rem', width: '100%' }}>
                <span style={{ color: 'var(--text-dark)', fontWeight: 'bold' }}>
                  {skill.level}%
                </span>
              </div>
              
              <div style={{ 
                width: '100%', 
                height: '10px', 
                background: 'var(--bg-light)', 
                borderRadius: '10px', 
                marginBottom: '0.5rem',
                border: '1px solid var(--border-color)'
              }}>
                <div style={{
                  width: `${skill.level}%`,
                  height: '100%',
                  background: 'var(--gradient)',
                  borderRadius: '10px',
                  transition: 'width 0.5s ease'
                }}></div>
              </div>
              
              <span style={{ 
                color: 'var(--text-light)', 
                fontSize: '0.85rem'
              }}>
                Porcentaje dominado
              </span>
            </div>

            {/* Lógica de confirmación en la interfaz */}
            <div className="admin-actions">
                {confirmingDeleteId === skill.id ? (
                    <>
                        <button 
                            onClick={() => handleDelete(skill.id, skill.name)}
                            className="btn-danger"
                            style={{ background: '#dc2626' }}
                            disabled={loading}
                        >
                            Confirmar Eliminación
                        </button>
                        <button 
                            onClick={cancelDelete}
                            className="btn-secondary"
                            disabled={loading}
                        >
                            Cancelar
                        </button>
                    </>
                ) : (
                    <>
                        <button 
                            onClick={() => handleEdit(skill)}
                            className="btn-secondary"
                            disabled={loading}
                        >
                            Editar
                        </button>
                        <button 
                            onClick={() => startDeleteConfirmation(skill.id)}
                            className="btn-danger"
                            disabled={loading}
                        >
                            Eliminar
                        </button>
                    </>
                )}
            </div>
          </div>
        )) : (
          <div style={{ 
            textAlign: 'center', 
            padding: '3rem', 
            color: 'var(--text-light)',
            gridColumn: '1 / -1'
          }}>
            <p>No hay habilidades registradas</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SkillForm;