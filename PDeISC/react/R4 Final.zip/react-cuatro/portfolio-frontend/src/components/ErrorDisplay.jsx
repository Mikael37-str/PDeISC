const ErrorDisplay = ({ message }) => (
  <div className="error">{message}</div>
);

export default ErrorDisplay;