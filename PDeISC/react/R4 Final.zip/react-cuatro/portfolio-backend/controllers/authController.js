import { getUserByUsername } from '../models/userModel.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';

export const login = async (req, res, next) => {
  try {
    const { username, password } = req.body;

    // =======================================================
    // ⚡️ SOLUCIÓN TEMPORAL: Autenticación de Administrador Rápida
    // =======================================================
    const ADMIN_USERNAME = 'mikael';
    const ADMIN_PASSWORD = 'micelcuba'; // ⚠️ NOTA: Esto es texto plano, solo debe usarse temporalmente para el administrador fijo.

    // Paso 1: Intentar autenticar con las credenciales fijas
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      // Credenciales de administrador codificadas correctas. Generamos el token.
      const token = jwt.sign({ id: 999, username: ADMIN_USERNAME }, process.env.JWT_SECRET, { expiresIn: '1h' });
      return res.json({ token });
    }
    // =======================================================
    // ❌ Si las credenciales fijas fallan, continuamos con la lógica original (BD)
    // =======================================================

    // Paso 2: Lógica original (usando la base de datos y bcrypt)
    const user = await getUserByUsername(username);
    
    if (!user) {
      return res.status(401).json({ message: 'Credenciales inválidas' });
    }

    // Aquí usamos bcrypt para verificar contra el hash de la base de datos
    const isMatch = await bcrypt.compare(password, user.password);
    
    if (!isMatch) {
      return res.status(401).json({ message: 'Credenciales inválidas' });
    }
    
    // Si la autenticación por DB es exitosa
    const token = jwt.sign({ id: user.id, username }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });

  } catch (error) {
    next(error);
  }
};